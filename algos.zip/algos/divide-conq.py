import time

def divide_and_conquer_match(text, pattern):
    def match(text, pattern, start, end):
        # Base case: if the segment is too small, check directly
        segment = text[start:end]  # Extracts the segment between start and end
        index = segment.find(pattern)
        if index != -1:
            return start + index  # Return the absolute index in the original text
        
        # Divide: Split the segment into two halves
        if len(segment) < len(pattern):
            return -1
        mid = (start + end) // 2
        left = match(text, pattern, start, mid)
        if left != -1:
            return left  # If found in the left half, return immediately
        right = match(text, pattern, mid, end)
        return right  # Return result from the right half (or -1 if not found)

    # Start the recursive search
    return match(text, pattern, 0, len(text))

# Example usage
text = "pootataooboi"
pattern = "boi"

# Timing the function
start_time = time.time()  # Record the start time
result = divide_and_conquer_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time

if result != -1:
    print(f"The pattern '{pattern}' was found in the text at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")
#worst case
text = "barceaboi"
pattern = "boi"

# Timing the function
start_time = time.time()  # Record the start time
result = divide_and_conquer_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time
print("worst case")
if result != -1:
    print(f"The pattern '{pattern}' was found in the text at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")
#best case
text = "boi"
pattern = "boi"
start_time = time.time()  # Record the start time
result = divide_and_conquer_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time
print("best case")
if result != -1:
    print(f"The pattern '{pattern}' was found in the text at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")

