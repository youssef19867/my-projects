import time

def string_match(text, pattern, current_index=0):
    # Base case: If the text is shorter than the pattern, no match is possible.
    if len(text) < len(pattern):
        return -1  # Return -1 to indicate no match.
    
    # Check if the pattern matches the beginning of the current text slice.
    if text[:len(pattern)] == pattern:
        return current_index  # Return the starting index of the match.
    
    # Recursive step: Check the rest of the text.
    return string_match(text[1:], pattern, current_index + 1)

# Example usage:
text = "potatoboi"
pattern = "boi"

start_time = time.time()  # Record the start time
result = string_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time
print("average case")
if result != -1:
    print(f"The pattern '{pattern}' was found at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")
#worst case"
text = "potatoboi"
pattern = "boi"

start_time = time.time()  # Record the start time
result = string_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time
print("worst case")
if result != -1:
    print(f"The pattern '{pattern}' was found at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")
#best case
text = "boi"
pattern = "boi"

start_time = time.time()  # Record the start time
result = string_match(text, pattern)
end_time = time.time()  # Record the end time

execution_time = end_time - start_time
print("best case")
if result != -1:
    print(f"The pattern '{pattern}' was found at index {result}.")
else:
    print(f"The pattern '{pattern}' was not found in the text.")

print(f"Execution time: {execution_time:.10f} seconds")

