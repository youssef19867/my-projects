#include<iostream>
#include<conio.h>;
using namespace std;
//function for the consumable that increases health
void ersemhealthbox(char x[][120], int rowofhealthbox, int  columnofhealthbox, int  ishealthbox)
{
	if (ishealthbox == 0)
	{


		x[rowofhealthbox][columnofhealthbox] = 3;
	}


}
void  checkhealthbox(char x[][120], int& rowofhealthbox, int& columnofhealthbox, int& ishealthbox, int  rowofhero, int  columnofhero, int& healthofhero)
{
	if (ishealthbox == 0)
	{
		if (rowofhealthbox == rowofhero + 1 || rowofhealthbox == rowofhero + 2 || rowofhealthbox == rowofhero)
		{
			if (columnofhealthbox == columnofhero && healthofhero > 0 && healthofhero < 5)
			{
				healthofhero = 5;
				ishealthbox = 1;
			}

		}
	}
}
void healthofenemyboss(int& rowofbullet, int& columnofbullet, int& rowofbossenemy, int& columnofbossenemy, int& healthofbossenemy, int& isbossenemy, int& isbullet, char& directionofbullet, int& isbossenemydead, int& bossenemyisfalling)
{
	if (directionofbullet == 'r' && healthofbossenemy > 0)
	{
		if (rowofbullet <= rowofbossenemy + 3 && rowofbullet >= rowofbossenemy)
		{
			if (columnofbullet >= columnofbossenemy - 3 && columnofbullet <= columnofbossenemy + 3 || columnofbullet++ >= columnofbossenemy - 3 && columnofbullet <= columnofbossenemy + 3)
			{

				if (isbullet == 1)
				{
					healthofbossenemy--;
					isbullet = -1;
				}
			}
		}
	}

	//for left direction of bullet damage enemy
	if (directionofbullet == 'l' && healthofbossenemy > 0)
	{
		if (rowofbullet <= rowofbossenemy + 3 && rowofbullet >= rowofbossenemy)
		{
			if (columnofbullet <= columnofbossenemy + 3 && columnofbullet >= columnofbossenemy - 3 || columnofbullet-- <= columnofbossenemy + 3 && columnofbullet-- >= columnofbossenemy - 1)
			{
				if (isbullet == 1)
				{
					healthofbossenemy--;
					isbullet = -1;
				}

			}
		}
	}

	//for when meleeenemy has no health
	if (healthofbossenemy == 0 && isbossenemy == 1)
	{
		isbossenemy = 2;
	}

}

void allenemiesdead(int& isenemydead, int& ismeleeenemydead, int& issheildenemydead, int& isallenemiesdead, int& rowofbossenemy, int& columnofbossenemy, int& isbossenemy)
{
	//this function checks if all the enemies are dead so we can spawn the boss enemy
	if (isenemydead == 1 && ismeleeenemydead == 1 && issheildenemydead == 1)
	{
		isallenemiesdead = 1;
	}
	if (isallenemiesdead == 1 && isbossenemy == 0)
	{
		rowofbossenemy = 6;
		columnofbossenemy = 5;
		isbossenemy = 1;
	}

}

void ersembossenemy(char x[][120], int& isallenemiesdead, int& rowofbossenemy, int& columnofbossenemy, int& healthofbossenemy, int& isbossenemy, int& money)
{
	///this function draws the boss enemy
	if (isbossenemy == 1)
	{
		x[rowofbossenemy][columnofbossenemy] = 2;
		x[rowofbossenemy + 1][columnofbossenemy] = 219;
		x[rowofbossenemy + 2][columnofbossenemy] = 219;
		x[rowofbossenemy + 1][columnofbossenemy + 1] = '\\';
		x[rowofbossenemy + 1][columnofbossenemy - 1] = '//';
		x[rowofbossenemy + 3][columnofbossenemy - 1] = '/';
		x[rowofbossenemy + 3][columnofbossenemy + 1] = '\\';
		if (healthofbossenemy == 8)
		{
			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 4] = 3;
		}
		if (healthofbossenemy == 7)
		{
			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 3] = 3;
		}
		if (healthofbossenemy == 6)
		{
			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 2] = 3;

		}
		if (healthofbossenemy == 5)
		{

			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy] = 3;
			x[rowofbossenemy - 1][columnofbossenemy + 1] = 3;


		}
		if (healthofbossenemy == 4)
		{

			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;
			x[rowofbossenemy - 1][columnofbossenemy] = 3;


		}
		if (healthofbossenemy == 3)
		{

			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 1] = 3;



		}
		if (healthofbossenemy == 2)
		{

			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;
			x[rowofbossenemy - 1][columnofbossenemy - 2] = 3;



		}
		if (healthofbossenemy == 1)
		{

			x[rowofbossenemy - 1][columnofbossenemy - 3] = 3;




		}
		if (healthofbossenemy <= 0)
		{
			money += 2;
			isbossenemy = 2;
		}
		if (isbossenemy == 2)
		{
			rowofbossenemy = 99999;
			columnofbossenemy = 99999;
		}
	}

}

void checkbossenemy(char x[][120], int& rowofbossenemy, int& columnofbossenemy, int& rowofhero, int& columnofhero, int& healthofhero, int& isbossenemy, int& isherolongjump, int& isherojump, int& heroisinelevator, int& bossenemyisfalling, int& isbossenemydead)
{
	//this function checks where the hero is and moves the boss accordingly. btw he can telaport but not when u are jumping or inside of an elevator
	if (isbossenemy == 1)
	{
		//below is for teleporting down
		if (rowofbossenemy < rowofhero && isherolongjump == 0 && isherojump == 0 && heroisinelevator == 0 && heroisinelevator != 3)///this is for teleporting the boss enemy up and down
		{

			if (x[rowofhero + 8][columnofhero] != '-' && x[rowofhero + 8][columnofhero] != '_' && bossenemyisfalling == 0)
			{
				rowofbossenemy += 5;
			}


			if (columnofbossenemy - 1 == columnofhero && rowofbossenemy >= rowofhero && rowofbossenemy < rowofhero + 3)//for when the hero is on the left side
			{
				healthofhero--;
				rowofhero -= 3;
				columnofhero -= 3;
			}
			if (columnofbossenemy + 1 == columnofhero && rowofbossenemy >= rowofhero && rowofbossenemy < rowofhero + 3)//for when the hero is on the right side
			{
				healthofhero--;
				rowofhero -= 3;
				columnofhero += 3;
			}
		}
		//below is for telaporting up
		if (rowofbossenemy > rowofhero && isherolongjump == 0 && isherojump == 0 && heroisinelevator == 0 && heroisinelevator != 3)///this is for teleporting the boss enemy up and down
		{


			if (x[rowofhero - 8][columnofhero] != '-' && x[rowofhero + 8][columnofhero] != '_')
			{
				rowofbossenemy -= 5;
			}


			if (columnofbossenemy - 1 == columnofhero)//for when the hero is on the left side
			{
				healthofhero--;
				rowofhero -= 3;
				columnofhero -= 3;
			}
			if (columnofbossenemy + 1 == columnofhero)//for when the hero is on the right side
			{
				healthofhero--;
				rowofhero -= 3;
				columnofhero += 3;
			}
		}

		if (columnofbossenemy < columnofhero)//this is for moving right
		{
			columnofbossenemy++;
		}
		if (columnofbossenemy > columnofhero)//this is for moving left
		{
			columnofbossenemy--;
		}
	}


}

void garvityofbossenemy(char x[][120], int& rowofbossenemy, int& columnofbossenemy, int& bossenemyisfalling)
{
	if (x[rowofbossenemy + 4][columnofbossenemy] == ' ')
	{
		bossenemyisfalling = 1;
		rowofbossenemy++;
	}
	else
	{
		bossenemyisfalling = 0;
	}
}

///ground spike trap 
void ersmgroundspiketrap(char x[][120], int rowofgroundspiketrap, int columnofgroundspiketrap)
{
	x[rowofgroundspiketrap][columnofgroundspiketrap] = 241;
	x[rowofgroundspiketrap][columnofgroundspiketrap + 1] = 241;
	x[rowofgroundspiketrap][columnofgroundspiketrap + 2] = 241;
	x[rowofgroundspiketrap][columnofgroundspiketrap + 3] = 241;
	x[rowofgroundspiketrap][columnofgroundspiketrap + 4] = 241;

}
void checkgroundspiketrap(char x[][120], int& rowofgroundspiketrap, int& columnofgroundspiketrap, int& rowofhero, int& columnofhero, int& healthofhero, int& isgroundspiketrap, char& directionofhero)
{
	if (rowofgroundspiketrap == rowofhero + 1 || rowofgroundspiketrap == rowofhero + 2 || rowofgroundspiketrap == rowofhero)
	{
		if (columnofgroundspiketrap + 4 == columnofhero || columnofgroundspiketrap == columnofhero || columnofgroundspiketrap + 3 == columnofhero || columnofgroundspiketrap + 2 == columnofhero || columnofgroundspiketrap == columnofhero)
		{
			if (directionofhero == 'r')
			{
				rowofhero -= 5;
				columnofhero -= 6;
			}
			if (directionofhero == 'l')
			{
				rowofhero -= 5;
				columnofhero += 6;
			}

			healthofhero--;
		}
	}




}

void portal(int money, int& isportal, char x[][120], int& rowofstartportal, int& columnofstartportal, int& rowofhero, int& columnofhero, int& rowofendportal, int& columnofendportal, int& spawnrowofhero, int& spawncolumnofhero)
{
	//function for portal logic and drawing
	if (money >= 2 && isportal == 0)
	{
		isportal = 1;
	}
	if (isportal == 1)
	{
		x[rowofstartportal - 1][columnofstartportal] = '/';
		x[rowofstartportal][columnofstartportal] = '\\';
		x[rowofstartportal - 1][columnofstartportal + 1] = '\\';
		x[rowofstartportal][columnofstartportal + 1] = '/';
		x[rowofendportal - 1][columnofendportal] = '/';
		x[rowofendportal][columnofendportal] = '\\';
		x[rowofendportal - 1][columnofendportal + 1] = '\\';
		x[rowofendportal][columnofendportal + 1] = '/';
		if (rowofhero == rowofstartportal || rowofhero + 1 == rowofstartportal || rowofhero - 1 == rowofstartportal)
		{
			if (columnofhero + 1 == columnofstartportal || columnofhero - 1 == columnofstartportal || columnofhero == columnofstartportal)
			{
				rowofhero = rowofendportal - 3;
				columnofhero = columnofendportal + 2;
				spawnrowofhero = rowofendportal;
				spawncolumnofhero = columnofendportal + 1;
				isportal = 2;

			}
		}
	}
	if (isportal == 2)
	{
		spawnrowofhero = rowofendportal - 1;
		spawncolumnofhero = columnofendportal + 2;
		x[rowofstartportal - 1][columnofstartportal] = '/';
		x[rowofstartportal][columnofstartportal] = '\\';
		x[rowofstartportal - 1][columnofstartportal + 1] = '\\';
		x[rowofstartportal][columnofstartportal + 1] = '/';
		x[rowofendportal - 1][columnofendportal] = '/';
		x[rowofendportal][columnofendportal] = '\\';
		x[rowofendportal - 1][columnofendportal + 1] = '\\';
		x[rowofendportal][columnofendportal + 1] = '/';
		if (rowofhero == rowofendportal || rowofhero + 1 == rowofendportal || rowofhero - 1 == rowofendportal)
		{
			if (columnofhero + 1 == columnofendportal || columnofhero - 1 == columnofendportal || columnofhero == columnofendportal)
			{
				rowofhero = rowofstartportal - 1;
				columnofhero = columnofstartportal - 2;
				spawnrowofhero = rowofstartportal - 1;
				spawncolumnofhero = columnofstartportal - 2;

				isportal = 1;

			}
		}
	}
	//note:when isportal=1 we will telaport to the second submatrix but to go to the third sub matrix we will have to create the elevator
}
void earsemhealth(char x[][120], int& rowofhero, int& columnofhero, int& healthofhero, int& spawnrowofhero, int& spawncolumnofhero, int& isrespawn)
{
	//for displaying health nad respawning the hero

	if (healthofhero == 5)
	{

		x[rowofhero - 1][columnofhero - 2] = 3;
		x[rowofhero - 1][columnofhero - 1] = 3;
		x[rowofhero - 1][columnofhero] = 3;
		x[rowofhero - 1][columnofhero + 1] = 3;
		x[rowofhero - 1][columnofhero + 2] = 3;
	}
	if (healthofhero == 4)
	{

		x[rowofhero - 1][columnofhero - 2] = 3;
		x[rowofhero - 1][columnofhero - 1] = 3;
		x[rowofhero - 1][columnofhero] = 3;
		x[rowofhero - 1][columnofhero + 1] = 3;
	}
	if (healthofhero == 3)
	{
		x[rowofhero - 1][columnofhero - 2] = 3;
		x[rowofhero - 1][columnofhero - 1] = 3;
		x[rowofhero - 1][columnofhero] = 3;
	}
	if (healthofhero == 2)
	{
		x[rowofhero - 1][columnofhero - 2] = 3;
		x[rowofhero - 1][columnofhero - 1] = 3;
	}
	if (healthofhero == 1)
	{
		x[rowofhero - 1][columnofhero - 2] = 3;
	}
	if (healthofhero <= 0)
	{
		isrespawn = 1;
	}
}
void ersemhero(char x[][120], int& rowofhero, int& columnofhero, char directionofhero, int& isrespawn, int& spawnrow, int& spawncolumn, int& healthofhero)
{
	//this function is responsble for drawing the hero
	if (isrespawn == 0)
	{


		x[rowofhero][columnofhero] = 1;
		x[rowofhero + 1][columnofhero] = 'l';
		x[rowofhero + 1][columnofhero + 1] = '>';
		if (directionofhero == 'r')
		{
			x[rowofhero + 1][columnofhero + 2] = 169;
		}
		if (directionofhero == 'l')
		{
			x[rowofhero + 1][columnofhero - 2] = 170;
		}
		x[rowofhero + 1][columnofhero - 1] = '<';
		x[rowofhero + 2][columnofhero] = '^';
	}
	if (isrespawn == 1)
	{
		rowofhero = spawnrow;
		columnofhero = spawncolumn;
		isrespawn = 0;
		healthofhero = 5;
	}
}
void gravityofhero(char x[][120], int& rowofhero, int& columnofhero, int isherojump, int isherolongjump, int& iselevator, int& heroisinelevator, int& heroisfalling)
{

	//this function pulls the hero downwards if there is no floor
	if (heroisinelevator == 0)
	{
		if (x[rowofhero + 2][columnofhero] == ' ' && rowofhero + 1 < 42 && isherojump == 0 && isherolongjump == 0 && x[rowofhero + 2][columnofhero] != '-')
		{
			rowofhero++;
			heroisfalling = 1;
		}
		else
		{
			heroisfalling = 0;
		}
	}
}
void harakhero(char x[][120], char& directionofhero, int& rowofhero, int& columnofhero, char movement, int& isherojump, int& jumpcells, int& isherolongjump, int& longjumpcells, int& isbullet, int& bulletcells, char& directionofbullet, int& originalcolumnofbullet, int heroisspiketrap, int& iselevator, int& requestelevator, int& heroisinelevator, int& heroisfalling)
{
	//this functions is responsible for moving the hero and also for the jump
	if (movement == 'a' && columnofhero - 3 >= 3 && heroisspiketrap == 0)
	{
		columnofhero -= 3;
		directionofhero = 'l';
	}
	if (movement == 's' && heroisspiketrap == 0)
	{
		if (directionofhero == 'l' && columnofhero - 6 >= 6)
		{
			columnofhero -= 6;
		}
		if (directionofhero == 'r' && columnofhero + 6 < 118)
		{
			columnofhero += 6;
		}
	}
	if (movement == 'd' && columnofhero + 3 < 118 && heroisspiketrap == 0)
	{
		columnofhero += 3;
		directionofhero = 'r';
	}
	if (movement == 'j' && isherojump != 1 && isherolongjump == 0 && heroisspiketrap == 0 && heroisinelevator == 0 && heroisfalling == 0)
	{
		isherojump = 1;
		jumpcells = 6
			;

	}
	if (movement == 'l' && isherolongjump != 1 && isherojump == 0 && heroisspiketrap == 0 && heroisinelevator == 0 && heroisfalling == 0)
	{
		isherolongjump = 1;
		longjumpcells = 13;

	}
	if (movement == 'f' && isbullet == -1 && heroisspiketrap == 0)
	{
		originalcolumnofbullet = columnofhero;
		isbullet = 0;
		bulletcells = 26;
		directionofbullet = directionofhero;
	}
	if (movement == 'e' && isherolongjump != 1 && isherojump == 0 && heroisspiketrap == 0)
	{
		requestelevator = 1;
	}


}
void earsemmeleeenemy(char x[][120], int& rowofmeleeenemy, int& columnofmeleeenemy, int& ismeleeenemydead, int& healthofmeleeenemy)
{
	//this function draws the melee enemy when he is not dead
	if (ismeleeenemydead == 0)
	{
		x[rowofmeleeenemy][columnofmeleeenemy] = 99;
		x[rowofmeleeenemy + 1][columnofmeleeenemy] = '|';
		x[rowofmeleeenemy + 1][columnofmeleeenemy + 1] = '\\';
		x[rowofmeleeenemy + 1][columnofmeleeenemy - 1] = '/';
		x[rowofmeleeenemy + 2][columnofmeleeenemy] = '^';
		if (healthofmeleeenemy == 5)
		{

			x[rowofmeleeenemy - 1][columnofmeleeenemy - 2] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy - 1] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy + 1] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy + 2] = 3;
		}
		if (healthofmeleeenemy == 4)
		{

			x[rowofmeleeenemy - 1][columnofmeleeenemy - 2] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy - 1] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy + 1] = 3;
		}
		if (healthofmeleeenemy == 3)
		{

			x[rowofmeleeenemy - 1][columnofmeleeenemy - 2] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy - 1] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy] = 3;

		}
		if (healthofmeleeenemy == 2)
		{

			x[rowofmeleeenemy - 1][columnofmeleeenemy - 2] = 3;
			x[rowofmeleeenemy - 1][columnofmeleeenemy - 1] = 3;


		}
		if (healthofmeleeenemy == 1)
		{

			x[rowofmeleeenemy - 1][columnofmeleeenemy - 2] = 3;



		}



	}
	if (ismeleeenemydead == 1)
	{
		rowofmeleeenemy = 99999;
		columnofmeleeenemy = 999;
	}

}
void meleeenemyhealth(int& rowofbullet, int& columnofbullet, int& rowofmeleeenemy, int& columnofmeleeenemy, char& directionofbullet, int& healthofmeleeenemy, int& isbullet, int& meleeenemyisdead, int& money)
{
	//function for checking if meleeenemy is going to get damaged by bullet and for displaying meleeenemyhealth

	//for right direction of bullet damage enemy
	if (directionofbullet == 'r' && healthofmeleeenemy > 0)
	{
		if (rowofbullet <= rowofmeleeenemy + 2 && rowofbullet >= rowofmeleeenemy)
		{
			if (columnofbullet >= columnofmeleeenemy - 3 && columnofbullet <= columnofmeleeenemy + 3 || columnofbullet++ >= columnofmeleeenemy - 3 && columnofbullet <= columnofmeleeenemy + 3)
			{

				if (isbullet == 1)
				{
					healthofmeleeenemy--;
					isbullet = -1;
				}

			}
		}
	}

	//for left direction of bullet damage enemy
	if (directionofbullet == 'l' && healthofmeleeenemy > 0)
	{
		if (rowofbullet <= rowofmeleeenemy + 2 && rowofbullet >= rowofmeleeenemy)
		{
			if (columnofbullet <= columnofmeleeenemy + 3 && columnofbullet >= columnofmeleeenemy - 3 || columnofbullet-- <= columnofmeleeenemy + 3 && columnofbullet-- >= columnofmeleeenemy - 1)
			{
				if (isbullet == 1)
				{
					healthofmeleeenemy--;
					isbullet = -1;
				}

			}
		}
	}

	//for when meleeenemy has no health
	if (healthofmeleeenemy == 0 && meleeenemyisdead == 0)
	{
		meleeenemyisdead = 1;
		money++;

	}
}
void checkmeleeenemy(int& columnofmeleeenemy, int& rowofmeleeenemy, int& columnofhero, int& rowofhero, int& ismeleeenemy, int& meleeenemycells)
{
	//this function is responsible for checking if the melee enemy is next to the hero

	if (columnofmeleeenemy > columnofhero && rowofmeleeenemy == rowofhero)
	{



		if (ismeleeenemy == -1)
		{

			meleeenemycells = 15;
			ismeleeenemy = 1;
		}



	}
	if (columnofmeleeenemy < columnofhero && rowofmeleeenemy == rowofhero)
	{



		if (ismeleeenemy == -1)
		{
			meleeenemycells = 15;
			ismeleeenemy = 2;
		}


	}
	if (rowofmeleeenemy != rowofhero)
	{
		ismeleeenemy = 0;
	}


}

void herekmeleeenemy(char x[][120], int& rowofmeleeenemy, int& columnofmeleeenemy, int& ismeleeenemy, int& meleeenemycells, int& originalcolumnofmeleeenemy, int columnofhero, int rowofhero, int& isrespawn, int& healthofhero)
{
	//this function moves the melee enemy
	if (ismeleeenemy == 0)//for going back to original location
	{
		if (originalcolumnofmeleeenemy < columnofmeleeenemy)
		{
			columnofmeleeenemy--;
		}
		if (originalcolumnofmeleeenemy > columnofmeleeenemy)
		{
			columnofmeleeenemy++;
		}
		if (columnofmeleeenemy == originalcolumnofmeleeenemy)
		{
			ismeleeenemy = -1;
		}
	}
	if (ismeleeenemy == 1)//moves left
	{
		if (rowofmeleeenemy == rowofhero && columnofmeleeenemy == columnofhero + 1)//this if is for the melee enemy
		{
			healthofhero = 0;
		}
		if (columnofmeleeenemy != columnofhero)
		{
			if (x[rowofmeleeenemy + 2][columnofmeleeenemy] != '-')
			{
				ismeleeenemy = 0;
			}
			columnofmeleeenemy--;
		}
		else
		{
			ismeleeenemy = 0;
		}
	}
	if (ismeleeenemy == 2)//moves right
	{
		if (rowofmeleeenemy == rowofhero && columnofmeleeenemy == columnofhero - 1)//this if is for the melee enemy
		{
			healthofhero = 0;
		}


		if (columnofmeleeenemy != columnofhero)
		{
			if (x[rowofmeleeenemy + 2][columnofmeleeenemy] != '-')
			{
				ismeleeenemy = 0;

			}
			columnofmeleeenemy++;
		}
		else
		{
			ismeleeenemy = 0;
		}


	}


}

void rangedenemyhealth(int& rowofbullet, int& columnofbullet, int& rowofenemy, int& columnofenemy, int& healthofenemy, int& enemyisdead, int& isbullet, char directionofbullet, int& money)
{
	//same as the one for the meleeenemy but for the bullet enemy
	if (directionofbullet == 'r' && healthofenemy > 0)
	{
		if (rowofbullet <= rowofenemy + 2 && rowofbullet >= rowofenemy)
		{
			if (columnofbullet >= columnofenemy - 3 && columnofbullet <= columnofenemy + 3 || columnofbullet++ >= columnofenemy - 3 && columnofbullet <= columnofenemy + 3)
			{

				if (isbullet == 1)
				{
					healthofenemy--;
					isbullet = -1;
				}

			}
		}
	}

	//for left direction of bullet damage enemy
	if (directionofbullet == 'l' && healthofenemy > 0)
	{
		if (rowofbullet <= rowofenemy + 2 && rowofbullet >= rowofenemy)
		{
			if (columnofbullet <= columnofenemy + 3 && columnofbullet >= columnofenemy - 3 || columnofbullet-- <= columnofenemy + 3 && columnofbullet-- >= columnofenemy - 1)
			{
				if (isbullet == 1)
				{
					healthofenemy--;
					isbullet = -1;
				}

			}
		}
	}

	//for when meleeenemy has no health
	if (healthofenemy == 0 && enemyisdead == 0)
	{
		enemyisdead = 1;
		money++;
	}

}


void herekenemybullet(int& enemybulletcells, int& isenemybullet, int& columnofenemybullet, int& enemyisdead)
{
	//this function works similiarly to the reqular hero bullet but for the enemy

	if (enemybulletcells > 0 && isenemybullet == 1 && enemyisdead == 0)
	{
		columnofenemybullet--;
		enemybulletcells--;
		if (enemybulletcells <= 0)
		{
			isenemybullet = 0;
		}
	}
	if (enemybulletcells > 0 && isenemybullet == 2 && enemyisdead == 0)
	{
		columnofenemybullet++;
		enemybulletcells--;
		if (enemybulletcells <= 0)
		{
			isenemybullet = 0;
		}
	}
	if (enemyisdead == 1)
	{
		isenemybullet = 0;
	}

}
void earsemenemybullet(char x[][120], int rowofenemybullet, int columnofenemybullet, int isenemybullet, int& healthofhero)
{
	//this function draws the enemys bullet
	if (isenemybullet == 1 || isenemybullet == 2)
	{
		x[rowofenemybullet][columnofenemybullet] = '~';
		if (x[rowofenemybullet][columnofenemybullet + 1] == 'l' || x[rowofenemybullet - 1][columnofenemybullet + 1] == 'l' || x[rowofenemybullet + 1][columnofenemybullet + 1] == 'l')
		{
			healthofhero--;
		}
	}
}
void checkbulletenemy(int& rowofenemy, int& columnofenemy, int columnofhero, int rowofhero, int& isenemybullet, int& enemybulletcells, int& rowofenemybullet, int& columnofenemybullet)
{
	//this function checks the space between the enemy and the hero to createe the enemy parameter
	if (columnofenemy > columnofhero && rowofenemy == rowofhero)
	{
		if (columnofenemy - columnofhero <= 20)
		{


			if (isenemybullet == 0)
			{
				isenemybullet = 1;
				enemybulletcells = 20;
				rowofenemybullet = rowofenemy + 1;
				columnofenemybullet = columnofenemy - 1;
			}
		}

	}
	if (columnofenemy < columnofhero && rowofenemy == rowofhero)
	{
		if (columnofhero - columnofenemy <= 20)
		{


			if (isenemybullet == 0)
			{
				isenemybullet = 2;
				enemybulletcells = 20;
				rowofenemybullet = rowofenemy + 1;
				columnofenemybullet = columnofenemy + 1;
			}
		}
	}
}
void earsemenemy(char x[][120], int& rowofenemy, int& columnofenemy, int isenemybullet, int& isenemydead, int& healthofenemy)
{
	//this function draws the enemy if he is alive
	if (isenemydead == 0)
	{
		x[rowofenemy][columnofenemy] = 2;
		x[rowofenemy + 1][columnofenemy] = '|';
		x[rowofenemy + 1][columnofenemy + 1] = '\\';
		if (isenemybullet == 1)
		{
			x[rowofenemy + 1][columnofenemy - 2] = 170;
		}
		x[rowofenemy + 1][columnofenemy - 1] = '/';
		if (isenemybullet == 2)
		{
			x[rowofenemy + 1][columnofenemy + 2] = 169;
		}
		x[rowofenemy + 2][columnofenemy] = '^';
		if (healthofenemy == 5)
		{

			x[rowofenemy - 1][columnofenemy - 2] = 3;
			x[rowofenemy - 1][columnofenemy - 1] = 3;
			x[rowofenemy - 1][columnofenemy] = 3;
			x[rowofenemy - 1][columnofenemy + 1] = 3;
			x[rowofenemy - 1][columnofenemy + 2] = 3;
		}
		if (healthofenemy == 4)
		{

			x[rowofenemy - 1][columnofenemy - 2] = 3;
			x[rowofenemy - 1][columnofenemy - 1] = 3;
			x[rowofenemy - 1][columnofenemy] = 3;
			x[rowofenemy - 1][columnofenemy + 1] = 3;

		}
		if (healthofenemy == 3)
		{

			x[rowofenemy - 1][columnofenemy - 2] = 3;
			x[rowofenemy - 1][columnofenemy - 1] = 3;
			x[rowofenemy - 1][columnofenemy] = 3;


		}
		if (healthofenemy == 2)
		{

			x[rowofenemy - 1][columnofenemy - 2] = 3;
			x[rowofenemy - 1][columnofenemy - 1] = 3;



		}
		if (healthofenemy == 1)
		{

			x[rowofenemy - 1][columnofenemy - 2] = 3;



		}
	}

	///for when he is dead
	if (isenemydead == 1)
	{
		rowofenemy = 99999;
		columnofenemy = 9999;
	}
}

void verticaljump(int& jumpcells, int& isherojump, int& rowofhero)
{
	if (jumpcells > 0 && isherojump == 1)
	{
		jumpcells -= 2;
		rowofhero -= 2;
	}
	if (jumpcells <= 0 && isherojump == 1)
	{
		jumpcells -= 2;
		rowofhero += 2;
		if (jumpcells == -6)///this is what stops the vertical jump
		{
			isherojump = 0;
		}
	}
}
void longjump(char x[][120], int& longjumpcells, int& isherolongjump, char directionofhero, int& rowofhero, int& columnofhero)
{
	//this series of ifs are responsible for the long jump logic
	if (longjumpcells > 0 && isherolongjump == 1)//this part is responspile for going up
	{
		longjumpcells -= 3;
		if (directionofhero == 'l')
		{
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;

			}
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;
			}
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;
			}
			else
			{
				longjumpcells = 0;///this else is here so that if the roof of the hero has a floor the jump starts going downwards
			}


			if (columnofhero - 3 > 0)
			{
				columnofhero -= 3;
			}


		}
		if (directionofhero == 'r')
		{
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;

			}
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;
			}
			if (x[rowofhero - 1][columnofhero] != '-' && x[rowofhero - 1][columnofhero] != '_')//to avoid phasing through the roof
			{
				rowofhero -= 1;
			}
			else
			{
				longjumpcells = 0;/////this else is here so that if the roof of the hero has a floor the jump starts going downwards
			}
			if (columnofhero + 3 < 119)
			{
				columnofhero += 3;
			}


		}
	}

	//this part below is responsible for going downwards
	if (longjumpcells <= 0 && isherolongjump == 1)
	{
		longjumpcells -= 3;
		if (directionofhero == 'l')
		{
			if (x[rowofhero + 4][columnofhero] != '-' && x[rowofhero + 3][columnofhero] != '-' && x[rowofhero + 2][columnofhero] != '-' && rowofhero + 3 < 41)
			{
				rowofhero += 3;

			}
			if (columnofhero - 3 > 0 && x[rowofhero - 3][columnofhero] == '-')
			{
				columnofhero -= 3;
			}

		}
		if (directionofhero == 'r')
		{
			if (x[rowofhero + 4][columnofhero] != '-' && x[rowofhero + 3][columnofhero] != '-' && x[rowofhero + 2][columnofhero] != '-' && rowofhero + 3 < 41)
			{
				rowofhero += 3;

			}
			if (columnofhero + 3 < 119 && x[rowofhero - 3][columnofhero] == '-')
			{
				columnofhero += 3;
			}

		}
		////////////////////////

		///this part below is what stops the jump
		if (longjumpcells <= -10)
		{
			isherolongjump = 0;
		}
	}
}



void ersemboarder(char x[][120])
{
	//this function creates the boarder
	for (int r = 0; r < 44; r++)
	{
		for (int c = 0; c < 120; c++)
		{
			x[r][c] = ' ';
		}
	}
	for (int r = 0; r < 44; r++)
	{
		x[r][0] = '|';
		x[r][119] = '|';
	}
	for (int c = 0; c < 120; c++)
	{
		x[0][c] = '_';
		x[42][c] = '_';
	}

	//border for floor 1 in submatrix 1
	for (int c = 15; c < 50; c++)
	{
		x[35][c] = '-';
	}
	//border for floor 2 in submatrix 1
	for (int c = 60; c < 90; c++)
	{
		x[35][c] = '-';
	}

	//submatrix 1 border
	for (int c = 0; c < 120; c++)
	{
		x[10][c] = '-';
	}
	//submatrix 2 border
	for (int c = 0; c < 120; c++)
	{
		x[26][c] = '-';
	}

	//border for floor 1 in submatrix 2
	for (int c = 35; c < 65; c++)
	{
		x[18][c] = '-';
	}

}
void harekbullet(char x[][120], int& rowofbullet, int& columnofbullet, int rowofhero, int columnofhero, char directionofhero, int& isbullet, int& bulletcells, char& directionofbullet, int& columnofenemysheild, int& originalcolumnofbullet, int rowofenemysheild, int& healthofhero, int& healthofenemysheild)
{	//this function moves the bullet depending on the bulletcells and if is bullet is equal to 1 or 0.it works similiarly to the jump function

	if (isbullet == 0 && directionofhero == 'r')
	{
		rowofbullet = rowofhero + 1;
		columnofbullet = columnofhero + 2;
		isbullet = 1;
	}
	if (isbullet == 0 && directionofhero == 'l')
	{
		rowofbullet = rowofhero + 1;
		columnofbullet = columnofhero - 2;
		isbullet = 1;
	}
	if (isbullet == 1 && directionofbullet == 'r' && bulletcells > 0)
	{
		if (columnofbullet + 5 == columnofenemysheild || columnofbullet + 4 == columnofenemysheild || columnofbullet + 3 == columnofenemysheild || columnofbullet + 2 == columnofenemysheild || columnofbullet++ == columnofenemysheild && rowofbullet == rowofenemysheild + 1)
		{
			if (rowofbullet == rowofenemysheild + 1)
			{
				healthofenemysheild--;
				isbullet = 3;
			}
			//note that return works like break
		}
		if (columnofbullet + 3 < 118)
		{
			columnofbullet += 3;
		}
		bulletcells -= 3;
	}
	if (isbullet == 1 && directionofbullet == 'l' && bulletcells > 0)
	{
		if (columnofbullet - 5 == columnofenemysheild || columnofbullet - 4 == columnofenemysheild || columnofbullet - 3 == columnofenemysheild || columnofbullet - 2 == columnofenemysheild || columnofbullet-- == columnofenemysheild && rowofbullet == rowofenemysheild + 1)
		{
			///this if is for the deflection for enemy sheild
			if (rowofbullet == rowofenemysheild + 1)
			{
				healthofenemysheild--;
				isbullet = 4;
			}
			//note that return works like break
		}
		if (columnofbullet - 3 > 0)
		{
			columnofbullet -= 3;
		}
		bulletcells -= 3;
	}
	if (isbullet == 3)
	{
		if (originalcolumnofbullet < columnofbullet)
		{
			if (x[rowofbullet][columnofbullet + 1] == 'l' || x[rowofbullet][columnofbullet] == 'l' || x[rowofbullet - 1][columnofbullet + 1] == 'l' || x[rowofbullet + 1][columnofbullet + 1] == 'l')
			{


				healthofhero--;

			}
			columnofbullet--;
			if (x[rowofbullet][columnofbullet] == 'l' || x[rowofbullet - 1][columnofbullet] == 'l' || x[rowofbullet - 1][columnofbullet - 1] == 'l' || x[rowofbullet + 1][columnofbullet - 1] == 'l')
			{


				healthofhero--;


			}

		}
		else
		{

			bulletcells = 0;
		}
	}
	if (isbullet == 4)
	{
		if (originalcolumnofbullet > columnofbullet)
		{

			columnofbullet++;
			if (x[rowofbullet][columnofbullet] == 'l' || x[rowofbullet - 1][columnofbullet] == 'l' || x[rowofbullet - 1][columnofbullet - 1] == 'l' || x[rowofbullet + 1][columnofbullet - 1] == 'l')
			{


				healthofhero--;


			}

		}
		else
		{

			bulletcells = 0;
		}
	}
	if (bulletcells <= 0)
	{
		isbullet = -1;
	}


}


void earsembullet(char x[][120], int rowofbullet, int columnofbullet, int rowofhero, int columnofhero, char directionofhero, int isbullet, char directionofbullet, int& healthofhero)
{
	//this function draws bullets on the board.note that 17 and 16 are asci characters 
	if (isbullet == 1 && directionofbullet == 'l')
	{
		x[rowofbullet][columnofbullet] = 17;
	}
	if (isbullet == 1 && directionofbullet == 'r')
	{
		x[rowofbullet][columnofbullet] = 16;
	}
	if (isbullet == 3)
	{


		x[rowofbullet][columnofbullet] = 17;
	}
	if (isbullet == 4)
	{

		x[rowofbullet][columnofbullet] = 16;
	}


}
void ersemenemyshield(char x[][120], int& rowofenemyshield, int& columnofenemyshield, int rowofhero, int columnofhero, int healthofsheildenemy, int& sheildenemyisdead, int& money)
{
	///for drawing sheildenemy
	if (healthofsheildenemy == 0 && sheildenemyisdead == 0)
	{
		money++;
		sheildenemyisdead = 1;
	}
	if (sheildenemyisdead == 0)
	{
		x[rowofenemyshield][columnofenemyshield] = 99;
		x[rowofenemyshield + 1][columnofenemyshield] = '|';
		x[rowofenemyshield + 1][columnofenemyshield + 1] = '\\';
		if (columnofhero > columnofenemyshield)
		{
			x[rowofenemyshield + 1][columnofenemyshield + 2] = 68;
		}
		if (columnofhero < columnofenemyshield)
		{
			x[rowofenemyshield + 1][columnofenemyshield - 2] = 68;
		}
		x[rowofenemyshield + 1][columnofenemyshield - 1] = '/';
		x[rowofenemyshield + 2][columnofenemyshield] = '^';
		if (healthofsheildenemy == 5)
		{

			x[rowofenemyshield - 1][columnofenemyshield - 2] = 3;
			x[rowofenemyshield - 1][columnofenemyshield - 1] = 3;
			x[rowofenemyshield - 1][columnofenemyshield] = 3;
			x[rowofenemyshield - 1][columnofenemyshield + 1] = 3;
			x[rowofenemyshield - 1][columnofenemyshield + 2] = 3;
		}
		if (healthofsheildenemy == 4)
		{

			x[rowofenemyshield - 1][columnofenemyshield - 2] = 3;
			x[rowofenemyshield - 1][columnofenemyshield - 1] = 3;
			x[rowofenemyshield - 1][columnofenemyshield] = 3;
			x[rowofenemyshield - 1][columnofenemyshield + 1] = 3;

		}
		if (healthofsheildenemy == 3)
		{

			x[rowofenemyshield - 1][columnofenemyshield - 2] = 3;
			x[rowofenemyshield - 1][columnofenemyshield - 1] = 3;
			x[rowofenemyshield - 1][columnofenemyshield] = 3;


		}
		if (healthofsheildenemy == 2)
		{

			x[rowofenemyshield - 1][columnofenemyshield - 2] = 3;
			x[rowofenemyshield - 1][columnofenemyshield - 1] = 3;



		}
		if (healthofsheildenemy == 1)
		{

			x[rowofenemyshield - 1][columnofenemyshield - 2] = 3;




		}
	}
	if (sheildenemyisdead == 1)
	{
		rowofenemyshield = 9999999;
		columnofenemyshield = 99999;
	}


}



void display(char x[][120])
{
	//this function displays the whole matrix alongside the changes that were made to the rows and columbs of the hero and enemies
	system("cls");
	for (int r = 0; r < 44; r++)
	{
		for (int c = 0; c < 120; c++)
		{
			cout << x[r][c];
		}
	}
}
void spiketrap(int& rowofhero, int& columnofhero, int& rowofspiketrap, int& columnofspiketrap, int& isspiketrapbullet, char& directionofspiketrapbullet, int& rowofspiketrapbullet, int& columnofspiketrapbullet)
{
	//this function checks if the hero is near by
	if (rowofspiketrap == rowofhero || rowofspiketrap == rowofhero + 1 && isspiketrapbullet == 0)
	{
		isspiketrapbullet = 1;

		//for checking if the hero is on the right or left

		if (columnofspiketrap > columnofhero)
		{
			directionofspiketrapbullet = 'l';
			rowofspiketrapbullet = rowofspiketrap;
			columnofspiketrapbullet = columnofspiketrap - 1;
		}
		if (columnofspiketrap < columnofhero)
		{
			directionofspiketrapbullet = 'r';
			rowofspiketrapbullet = rowofspiketrap;
			columnofspiketrapbullet = columnofspiketrap + 1;
		}

	}
	//this else is incase the player goes to a diffrent row



}
void herekspiketrapbullet(char x[][120], int& rowofhero, int& columnofhero, int& rowofspiketrap, int& columnofspiketrap, int& isspiketrapbullet, char& directionofspiketrapbullet, int& columnofspiketrapbullet, int& rowofspiketrapbullet, int& heroisspiketraped)
{
	//this function is responsible for moving the spike trap bullet and grapinng the hero. note:there is a diffrence between rowofsspiketrap and rowofspiketrapbullet
	if (isspiketrapbullet == 1)
	{
		if (directionofspiketrapbullet == 'l')
		{
			if (rowofspiketrap == rowofhero || rowofspiketrap == rowofhero + 1)
			{

			}
			else
			{
				isspiketrapbullet = 0;
			}

			if (columnofspiketrapbullet > columnofhero)
			{
				columnofspiketrapbullet--;
			}
			if (columnofspiketrapbullet == columnofhero + 1 || columnofspiketrapbullet == columnofhero)
			{

				heroisspiketraped = 1;
			}

		}
		if (directionofspiketrapbullet == 'r')
		{
			if (rowofspiketrap == rowofhero || rowofspiketrap == rowofhero + 1)
			{

			}
			else
			{
				isspiketrapbullet = 0;
			}


			if (columnofspiketrapbullet < columnofhero)
			{
				columnofspiketrapbullet++;
			}
			if (columnofspiketrapbullet == columnofhero - 1 || columnofspiketrapbullet == columnofhero)
			{

				heroisspiketraped = 1;
			}
		}
	}
}
void grapherospiketrap(char x[][120], int& rowofhero, int& columnofhero, int& rowofspiketrap, int& columnofspiketrap, int& isspiketrapbullet, char& directionofspiketrapbullet, int& columnofspiketrapbullet, int& rowofspiketrapbullet, int& heroisspiketraped, int& healthofhero)
{
	//this function moves the hero towards the spike trap if he gets caught
	if (heroisspiketraped == 1 && directionofspiketrapbullet == 'l')//grap the hero to te right
	{
		if (columnofspiketrapbullet < columnofspiketrap)
		{
			columnofspiketrapbullet++;
			columnofhero++;
		}
		if (columnofspiketrapbullet == columnofspiketrap)//for when the hero hass reached the spike trap
		{
			healthofhero -= 2;
			isspiketrapbullet = -9999999;
			heroisspiketraped = 0;
		}
	}
	if (heroisspiketraped == 1 && directionofspiketrapbullet == 'r')//grap the hero to the left
	{
		if (columnofspiketrapbullet > columnofspiketrap)
		{
			columnofspiketrapbullet--;
			columnofhero--;
		}
		if (columnofspiketrapbullet == columnofspiketrap)//for when the hero hass reached the spike trap
		{
			healthofhero -= 2;
			isspiketrapbullet = -9999999;
			heroisspiketraped = 0;
		}

	}
}
void ersemspiketrapbullet(char x[][120], int& rowofhero, int& columnofhero, int& rowofspiketrap, int& columnofspiketrap, int& isspiketrapbullet, char& directionofspiketrapbullet, int& columnofspiketrapbullet, int& rowofspiketrapbullet, int& heroisspiketraped)
{
	//this function draws the spike trap bullet
	if (isspiketrapbullet == 0)
	{
		x[rowofspiketrap][columnofspiketrap] = 232;

	}
	if (isspiketrapbullet > 0)
	{
		x[rowofspiketrap][columnofspiketrap] = 232;
		x[rowofspiketrapbullet][columnofspiketrapbullet] = '~';
	}
}
void checkelevator(int& rowofstartelevator, int& rowofendelevator, int& columnofstartelevator, int& columnofendelevator, int& rowofhero, int& columnofhero, int& iselevator, int& elevatorrequest, int& heroisinelevator)
{
	//for checing if the hero is inside the elevator
	if (columnofendelevator - 3 <= columnofhero && columnofendelevator + 3 >= columnofhero && iselevator == 2)
	{


		iselevator = 3;
		if (rowofhero + 2 < 26)
		{
			rowofhero++;
		}
		heroisinelevator = 1;


	}

	if (columnofstartelevator - 3 <= columnofhero && columnofstartelevator + 3 >= columnofhero && iselevator <= 1)
	{
		if (rowofstartelevator <= rowofhero + 1 && rowofstartelevator >= rowofhero - 1)
		{

			iselevator = 1;
			rowofhero--;
			heroisinelevator = 1;
		}
	}
	else
	{
		heroisinelevator = 0;
	}




}
void herekelevator(int& rowofstartelevator, int& rowofendelevator, int& columnofstartelevator, int& columnofendelevator, int& rowofhero, int& columnofhero, int& iselevator, int& rowofelevator, int& columnofelevator, int& elevatorrequestint, int& heroisinelevator)
{
	//note if iselevator = 1 then the elevator is going up,iselevator=2 means going down

	if (iselevator == 1)
	{

		if (rowofstartelevator != rowofendelevator)
		{
			rowofstartelevator--;

			if (heroisinelevator == 1)
			{
				rowofhero--;
			}

		}
		else
		{
			iselevator = 2;
			rowofstartelevator = 24;
			heroisinelevator = 0;
			if (columnofstartelevator - 3 <= columnofhero && columnofstartelevator + 3 >= columnofhero)
			{
				rowofhero++;
			}
		}
	}
	if (iselevator == 3)//for going down with the hero
	{


		if (rowofstartelevator != rowofendelevator)
		{
			if (heroisinelevator == 1)
			{
				if (rowofendelevator <= rowofhero + 1 && rowofendelevator >= rowofhero - 1)
				{
					rowofhero++;
				}
			}
			rowofendelevator++;
		}





		else
		{
			iselevator = 0;

			rowofhero--;
			rowofendelevator = 8;
			heroisinelevator = 0;
		}
	}
}
void earsemelevator(char x[][120], int& rowofstartelevator, int& rowofendelevator, int& columnofstartelevator, int& columnofendelevator, int& rowofhero, int& columnofhero, int& iselevator, int& rowofelevator, int& columnofelevator, int& elevatorrequest)
{
	if (iselevator == 0)
	{
		x[rowofstartelevator][columnofstartelevator - 3] = '|';
		x[rowofstartelevator - 1][columnofstartelevator - 3] = '|';
		x[rowofstartelevator + 1][columnofstartelevator - 3] = '|';
		///////////////////////////////////////////////////////////
		x[rowofstartelevator][columnofstartelevator + 3] = '|';
		x[rowofstartelevator - 1][columnofstartelevator + 3] = '|';
		x[rowofstartelevator + 1][columnofstartelevator + 3] = '|';
		////////////////////////////////////////////////////////////
		x[rowofstartelevator + 2][columnofstartelevator - 3] = '-';
		x[rowofstartelevator + 2][columnofstartelevator - 2] = '-';
		x[rowofstartelevator + 2][columnofstartelevator - 1] = '-';
		x[rowofstartelevator + 2][columnofstartelevator] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 1] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 2] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 3] = '-';
		////////////////////////////////////////////////////////////
		x[rowofstartelevator - 2][columnofstartelevator - 3] = '-';
		x[rowofstartelevator - 2][columnofstartelevator - 2] = '-';
		x[rowofstartelevator - 2][columnofstartelevator - 1] = '-';
		x[rowofstartelevator - 2][columnofstartelevator] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 1] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 2] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 3] = '-';
	}
	if (iselevator == 1)
	{
		x[rowofstartelevator][columnofstartelevator - 3] = '|';
		x[rowofstartelevator - 1][columnofstartelevator - 3] = '|';
		x[rowofstartelevator + 1][columnofstartelevator - 3] = '|';
		///////////////////////////////////////////////////////////
		x[rowofstartelevator][columnofstartelevator + 3] = '|';
		x[rowofstartelevator - 1][columnofstartelevator + 3] = '|';
		x[rowofstartelevator + 1][columnofstartelevator + 3] = '|';
		////////////////////////////////////////////////////////////
		x[rowofstartelevator + 2][columnofstartelevator - 3] = '-';
		x[rowofstartelevator + 2][columnofstartelevator - 2] = '-';
		x[rowofstartelevator + 2][columnofstartelevator - 1] = '-';
		x[rowofstartelevator + 2][columnofstartelevator] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 1] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 2] = '-';
		x[rowofstartelevator + 2][columnofstartelevator + 3] = '-';
		////////////////////////////////////////////////////////////
		x[rowofstartelevator - 2][columnofstartelevator - 3] = '-';
		x[rowofstartelevator - 2][columnofstartelevator - 2] = '-';
		x[rowofstartelevator - 2][columnofstartelevator - 1] = '-';
		x[rowofstartelevator - 2][columnofstartelevator] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 1] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 2] = '-';
		x[rowofstartelevator - 2][columnofstartelevator + 3] = '-';

	}
	if (iselevator == 2)
	{
		x[rowofendelevator][columnofendelevator - 3] = '|';
		x[rowofendelevator - 1][columnofendelevator - 3] = '|';
		x[rowofendelevator + 1][columnofendelevator - 3] = '|';
		///////////////////////////////////////////////////////////
		x[rowofendelevator][columnofendelevator + 3] = '|';
		x[rowofendelevator - 1][columnofendelevator + 3] = '|';
		x[rowofendelevator + 1][columnofendelevator + 3] = '|';
		////////////////////////////////////////////////////////////
		x[rowofendelevator + 2][columnofendelevator - 3] = '-';
		x[rowofendelevator + 2][columnofendelevator - 2] = '-';
		x[rowofendelevator + 2][columnofendelevator - 1] = '-';
		x[rowofendelevator + 2][columnofendelevator] = '-';
		x[rowofendelevator + 2][columnofendelevator + 1] = '-';
		x[rowofendelevator + 2][columnofendelevator + 2] = '-';
		x[rowofendelevator + 2][columnofendelevator + 3] = '-';
		////////////////////////////////////////////////////////////
		x[rowofendelevator - 2][columnofendelevator - 3] = '-';
		x[rowofendelevator - 2][columnofendelevator - 2] = '-';
		x[rowofendelevator - 2][columnofendelevator - 1] = '-';
		x[rowofendelevator - 2][columnofendelevator] = '-';
		x[rowofendelevator - 2][columnofendelevator + 1] = '-';
		x[rowofendelevator - 2][columnofendelevator + 2] = '-';
		x[rowofendelevator - 2][columnofendelevator + 3] = '-';
	}
	if (iselevator == 3)
	{
		x[rowofendelevator][columnofendelevator - 3] = '|';
		x[rowofendelevator - 1][columnofendelevator - 3] = '|';
		x[rowofendelevator + 1][columnofendelevator - 3] = '|';
		///////////////////////////////////////////////////////////
		x[rowofendelevator][columnofendelevator + 3] = '|';
		x[rowofendelevator - 1][columnofendelevator + 3] = '|';
		x[rowofendelevator + 1][columnofendelevator + 3] = '|';
		////////////////////////////////////////////////////////////
		x[rowofendelevator + 2][columnofendelevator - 3] = '-';
		x[rowofendelevator + 2][columnofendelevator - 2] = '-';
		x[rowofendelevator + 2][columnofendelevator - 1] = '-';
		x[rowofendelevator + 2][columnofendelevator] = '-';
		x[rowofendelevator + 2][columnofendelevator + 1] = '-';
		x[rowofendelevator + 2][columnofendelevator + 2] = '-';
		x[rowofendelevator + 2][columnofendelevator + 3] = '-';
		////////////////////////////////////////////////////////////
		x[rowofendelevator - 2][columnofendelevator - 3] = '-';
		x[rowofendelevator - 2][columnofendelevator - 2] = '-';
		x[rowofendelevator - 2][columnofendelevator - 1] = '-';
		x[rowofendelevator - 2][columnofendelevator] = '-';
		x[rowofendelevator - 2][columnofendelevator + 1] = '-';
		x[rowofendelevator - 2][columnofendelevator + 2] = '-';
		x[rowofendelevator - 2][columnofendelevator + 3] = '-';
	}
}



void main()
{
	//movement variables
	char directionofhero = 'r';
	char movement;//note:movement takes the movement of the hero
	///

	/////jump variables
	int isherojump = 0;//isherojump is a flag that tells u if you are in a jump
	int isherolongjump = 0;
	int longjumpcells = -10;
	int jumpcells = -5;//is responsible for the number of cells that the hero jumps
	/////

	///hero variables
	int rowofhero = 40, columnofhero = 41;
	char x[44][120];
	int spawnrowofhero = 40;
	int spawncolumnofhero = 30;
	int isrespawn = 0;
	int healthofhero = 5;
	int heroisfalling = 0;

	///

	///variables for bullets below
	int isbullet = -1;
	int bulletcells = 0;
	int columnofbullet = 0;
	int rowofbullet = 0;
	char directionofbullet = 'r';
	///
	/// Enemyshield variables
	int rowofenemyshield = 40, columnofenemyshield = 45;
	int isshieldbullet = 0;
	int originalcolumnofbullet = 0;
	int sheildenemyisdead = 0;
	int healthofsheildenemy = 5;

	///enemey variables
	int rowofenemy = 33;
	int columnofenemy = 28;
	int enemybulletcells = 0, isenemybullet = 0, columnofenemybullet = 0, rowofenemybullet = 0;
	int isenemydead = 0;
	int healthofenemy = 5;
	//

	//meleeenemy variables
	int rowofmeleeenemy = 33;
	int columnofmeleeenemy = 69;
	int ismeleeenemy = -1;
	int meleeenemycells = 0;
	int originalcolumnofmeleeenemy = 69;
	int healthofmeleeenemy = 5;
	int meleenemyisdead = 0;


	//portal variables
	int money = 0;
	int rowofstartportal = 41;
	int columnofstartportal = 110; ///note:start portal is where the portal starts and end portal is where the portal will send the hero to
	int rowofendportal = 25;
	int columnofendportal = 4;
	int isportal = 0;

	//spiketrap variables
	int rowofspiketrap = 17;
	int columnofspiketrap = 41;
	int isspiketrapbullet = 0;
	char directionofspiketrapbullet = 'l';
	int columnofspiketrapbullet;
	int rowofspiketrapbullet;
	int heroisspiketraped = 0;
	//healthbox variables
	int rowofhealthbox = 25;
	int columnofhealthbox = 60;
	int ishealthbox = 0;
	//groundspiketrapvariables
	int rowofgroundspiketrap = 26;
	int columnofgroundspiketrap = 24;
	int isgroundspiketrap = 0;

	//elevator variables
	int rowofstartelevator = 24;
	int rowofendelevator = 8;
	int columnofstartelevator = 115;
	int columnofendelevator = 115;
	int iselevator = 0;
	int elevatorrequest = 0;
	int rowofelevator;
	int columnofelevator;
	int heroisinelevator = 0;
	////

	//boss enemy variables
	int rowofbossenemy = 0;
	int columnofbossenemy = 0;
	int isallenemiesdead = 0;
	int isbossenemy = 0;
	int healthofbossenemy = 8;
	int bossenemyisfalling = 0;
	int isbossenemydead = 0;



	for (;;)//this for loop is the main loop for the game
	{
		for (; !_kbhit();)//this loop is for stationary objects and enemies its diffrent from the loop for movement
		{
			ersemboarder(x);
			//if statement that calls the vertical jump function
			if (isherojump == 1)
			{
				verticaljump(jumpcells, isherojump, rowofhero);
			}
			//

			///if statement that calls the long jump function
			if (isherolongjump == 1)
			{
				longjump(x, longjumpcells, isherolongjump, directionofhero, rowofhero, columnofhero);
			}
			///
			//ersemenemyranged1()
			//

			////////////////////////////////////////////////////////////////////////
			gravityofhero(x, rowofhero, columnofhero, isherojump, isherolongjump, iselevator, heroisinelevator, heroisfalling);

			earsemhealth(x, rowofhero, columnofhero, healthofhero, spawnrowofhero, spawncolumnofhero, isrespawn);
			ersemhero(x, rowofhero, columnofhero, directionofhero, isrespawn, spawnrowofhero, spawncolumnofhero, healthofhero);
			harekbullet(x, rowofbullet, columnofbullet, rowofhero, columnofhero, directionofhero, isbullet, bulletcells, directionofbullet, columnofenemyshield, originalcolumnofbullet, rowofenemyshield, healthofhero, healthofsheildenemy);
			earsembullet(x, rowofbullet, columnofbullet, rowofhero, columnofhero, directionofhero, isbullet, directionofbullet, healthofhero);
			/////////////////

			earsemenemy(x, rowofenemy, columnofenemy, isenemybullet, isenemydead, healthofenemy);
			rangedenemyhealth(rowofbullet, columnofbullet, rowofenemy, columnofenemy, healthofenemy, isenemydead, isbullet, directionofbullet, money);

			checkbulletenemy(rowofenemy, columnofenemy, columnofhero, rowofhero, isenemybullet, enemybulletcells, rowofenemybullet, columnofenemybullet);
			herekenemybullet(enemybulletcells, isenemybullet, columnofenemybullet, isenemydead);
			earsemenemybullet(x, rowofenemybullet, columnofenemybullet, isenemybullet, healthofhero);
			////
			meleeenemyhealth(rowofbullet, columnofbullet, rowofmeleeenemy, columnofmeleeenemy, directionofbullet, healthofmeleeenemy, isbullet, meleenemyisdead, money);

			checkmeleeenemy(columnofmeleeenemy, rowofmeleeenemy, columnofhero, rowofhero, ismeleeenemy, meleeenemycells);
			herekmeleeenemy(x, rowofmeleeenemy, columnofmeleeenemy, ismeleeenemy, meleeenemycells, originalcolumnofmeleeenemy, columnofhero, rowofhero, isrespawn, healthofhero);
			earsemmeleeenemy(x, rowofmeleeenemy, columnofmeleeenemy, meleenemyisdead, healthofmeleeenemy);
			//here we call the shielded enemy 

			ersemenemyshield(x, rowofenemyshield, columnofenemyshield, rowofhero, columnofhero, healthofsheildenemy, sheildenemyisdead, money);
			////

			//for portal 

			portal(money, isportal, x, rowofstartportal, columnofstartportal, rowofhero, columnofhero, rowofendportal, columnofendportal, spawnrowofhero, spawncolumnofhero);

			//for spike trap
			spiketrap(rowofhero, columnofhero, rowofspiketrap, columnofspiketrap, isspiketrapbullet, directionofspiketrapbullet, rowofspiketrapbullet, columnofspiketrapbullet);
			herekspiketrapbullet(x, rowofhero, columnofhero, rowofspiketrap, columnofspiketrap, isspiketrapbullet, directionofspiketrapbullet, columnofspiketrapbullet, rowofspiketrapbullet, heroisspiketraped);
			grapherospiketrap(x, rowofhero, columnofhero, rowofspiketrap, columnofspiketrap, isspiketrapbullet, directionofspiketrapbullet, columnofspiketrapbullet, rowofspiketrapbullet, heroisspiketraped, healthofhero);
			ersemspiketrapbullet(x, rowofhero, columnofhero, rowofspiketrap, columnofspiketrap, isspiketrapbullet, directionofspiketrapbullet, columnofspiketrapbullet, rowofspiketrapbullet, heroisspiketraped);
			////

			//health box and groundspiketrap
			ersemhealthbox(x, rowofhealthbox, columnofhealthbox, ishealthbox);
			checkhealthbox(x, rowofhealthbox, columnofhealthbox, ishealthbox, rowofhero, columnofhero, healthofhero);
			ersmgroundspiketrap(x, rowofgroundspiketrap, columnofgroundspiketrap);
			checkgroundspiketrap(x, rowofgroundspiketrap, columnofgroundspiketrap, rowofhero, columnofhero, healthofhero, isgroundspiketrap, directionofhero);
			////

			//elevator
			checkelevator(rowofstartelevator, rowofendelevator, columnofstartelevator, columnofendelevator, rowofhero, columnofhero, iselevator, elevatorrequest, heroisinelevator);
			herekelevator(rowofstartelevator, rowofendelevator, columnofstartelevator, columnofendelevator, rowofhero, columnofhero, iselevator, rowofelevator, columnofelevator, elevatorrequest, heroisinelevator);
			earsemelevator(x, rowofstartelevator, rowofendelevator, columnofstartelevator, columnofendelevator, rowofhero, columnofhero, iselevator, rowofelevator, columnofelevator, elevatorrequest);
			///

			//boss enemy
			allenemiesdead(isenemydead, meleenemyisdead, sheildenemyisdead, isallenemiesdead, rowofbossenemy, columnofbossenemy, isbossenemy);
			checkbossenemy(x, rowofbossenemy, columnofbossenemy, rowofhero, columnofhero, healthofhero, isbossenemy, isherolongjump, isherojump, heroisinelevator, bossenemyisfalling, isbossenemydead);
			garvityofbossenemy(x, rowofbossenemy, columnofbossenemy, bossenemyisfalling);
			ersembossenemy(x, isallenemiesdead, rowofbossenemy, columnofbossenemy, healthofbossenemy, isbossenemy, money);
			healthofenemyboss(rowofbullet, columnofbullet, rowofbossenemy, columnofbossenemy, healthofbossenemy, isbossenemy, isbullet, directionofbullet, isbossenemydead, bossenemyisfalling);


			////


			/////
			display(x);
		}
		//here we will calll the functions  for the movement of the hero
		movement = _getch();
		harakhero(x, directionofhero, rowofhero, columnofhero, movement, isherojump, jumpcells, isherolongjump, longjumpcells, isbullet, bulletcells, directionofbullet, originalcolumnofbullet, heroisspiketraped, iselevator, elevatorrequest, heroisinelevator, heroisfalling);

	}
}